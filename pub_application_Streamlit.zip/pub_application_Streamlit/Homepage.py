import streamlit as st
import numpy as numpy
import pandas as pd

st.title('UK Pubs Information')
st.text('')


df = pd.read_csv('data/pub.csv')

basic = st.selectbox('',('Total pubs in UK','Head','Tail','unique local authority','check_null_values'))

if basic=='Total pubs in UK':
    st.markdown(f'There  are  **{df.shape[0]}**  Pubs  in  **United Kingdom**')

elif basic=='Head':
    st.dataframe(df.head())

elif basic=='Tail':
    st.dataframe(df.tail())

elif basic=='unique local authority':
    st.text(f'Total no of pub local authority is {len(df.local_authority.unique())} in United Kingdom')

elif basic=='check_null_values':
    st.markdown('**We can see that there are no null values in our dataset**')
    st.text(df.isnull().sum())

elif basic=='Statistics information':
     st.dataframe(df.describe())

st.text('')
st.text('')

st.subheader('Find the Statistics information of the pub dataset')

stat = st.button('Describe')

if stat==True:
    st.dataframe(df.describe())
else:
    st.text('')
